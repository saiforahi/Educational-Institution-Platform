<div class="left_side_menu_btn_con">
    <div class="l_s_m_btn">
        <i class="fas fa-arrow-circle-right"></i>
    </div>
</div>
<section class="left_side_menu">
    <div class="l_s_m_container">
        <nav>
            <ul>
                @if(Auth::user()->admin||Auth::user()->user_details->type=="teacher")
                <li><a href="{{route('show_classes')}}">Classes</a></li>
                @endif
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item Last</a></li>
            </ul>
        </nav>
    </div>
    <div class="l_s_m_down_arrow">
        <i class="fas fa-arrow-circle-down"></i>
    </div>
</section>
<div class="l_s_m_btn_hide_con">
    <div class="l_s_m_btn_hide">
        <i class="fas fa-arrow-circle-left"></i>
    </div>
</div>


