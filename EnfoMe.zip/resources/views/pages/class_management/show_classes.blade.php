@extends('layouts.main')
@section('content')
 <h2>manage class</h2>   
@endsection