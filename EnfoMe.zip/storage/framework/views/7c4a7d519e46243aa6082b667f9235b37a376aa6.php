

<?php $__env->startSection('content'); ?>
    <div class="header_container">
    </div>
    <div class="text_con">
        <div class="text_one">
            <h2>Verify Your Email Address</h2>
        </div>
        <?php if(session('resent')): ?>
            <div class="text_one"> <h2>A fresh verification link has been sent to your email address.</h2></div>
            <div class="text_one"> <h2>If you did not receive the email,</h2></div>
        <?php else: ?>
            <div class="text_one"><h2>Before proceeding, please check your email for a verification link. If you did not receive the email,</h2></div>
        <?php endif; ?>
        <br>
        <form method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">Click here to request another</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/auth/verify.blade.php ENDPATH**/ ?>