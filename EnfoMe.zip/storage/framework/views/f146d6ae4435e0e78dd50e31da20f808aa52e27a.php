<div class="right_side_menu_btn_con">
    <div class="r_s_m_btn">
        <i class="fas fa-arrow-circle-left"></i>
    </div>
</div>
<section class="right_side_menu">
    <div class="r_s_m_container">
        <nav>
            <ul>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <!-- <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item Last</a></li> -->
            </ul>
        </nav>
    </div>
    <div class="r_s_m_down_arrow">
        <i class="fas fa-arrow-circle-down"></i>
    </div>
</section>
<div class="r_s_m_btn_hide_con">
    <div class="r_s_m_btn_hide">
        <i class="fas fa-arrow-circle-right"></i>
    </div>
</div><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/includes/body_right.blade.php ENDPATH**/ ?>