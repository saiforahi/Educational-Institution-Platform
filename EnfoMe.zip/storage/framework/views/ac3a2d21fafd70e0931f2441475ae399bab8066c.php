
<?php $__env->startSection('content'); ?>
 <h2>manage class</h2>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/pages/class_management/show_classes.blade.php ENDPATH**/ ?>