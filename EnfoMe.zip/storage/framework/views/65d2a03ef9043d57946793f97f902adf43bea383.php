
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Body-->
    <div class="body_container">
        <!--Responsive Tools-->
        <div id="body_container"></div>
        <!--Left Side of Body-->
        <?php echo $__env->make('layouts.body_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Left Side of Body-->

        <!--Center of body-->
        <!--Form body-->
        <div class="institute_pages_center_feed" id="bg_one">
            <div class="ins_detail_container">
                <div class="ins_profile_img_con">
                    <?php echo e($details->name[0]); ?>

                </div>
                <div class="ins_name_con">
                    <div class="ins_full_name">
                        <h1><?php echo e($details->name); ?></h1>
                    </div>
                    <div class="subscribe_btn">
                        <form action="<?php echo e(route('update_subscription')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($details->id); ?>" name="institute_id">
                            <button type="submit" name="submit" value="submit"><?php echo e(Auth::user()->isSubscribed($details->id)); ?></button>
                        </form>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $details->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('notification/details/'.$notification->id)); ?>">
                <div class="noti_container">
                    <div class="notification_name">
                        Notification
                    </div>
                    <div class="date_con">
                        2020/06/24
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo $__env->make('layouts.body_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

        
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/pages/single_institute.blade.php ENDPATH**/ ?>