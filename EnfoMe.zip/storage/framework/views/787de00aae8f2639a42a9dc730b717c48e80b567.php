<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <script src="https://kit.fontawesome.com/f8aa4258e3.js" crossorigin="anonymous"></script>
    <script>window.user=<?php echo json_encode(Auth::user());; ?>;console.log(window.user);</script>
    <title>EnfoMe || Dashboard</title>
    <link rel="icon" href="<?php echo e(asset('img/enfologo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/views.js')); ?>" defer></script>
</head>
<body>
    <div id="app">
        <main>
            <!----------------------------------Header Menu Section---------------------------------->
            <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!----------------------------------Left Side Menu---------------------------------->
            <?php echo $__env->make('includes.body_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!----------------------------------Right Side Menu---------------------------------->
            <?php echo $__env->make('includes.body_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!----------------------------------Left & Right Side Menu Responsive---------------------------------->
            <?php echo $__env->make('includes.responsive_right_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!----------------------------------Body---------------------------------->
            <section class="body_area">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>
    
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <?php echo $__env->yieldContent('js-part'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/layouts/main.blade.php ENDPATH**/ ?>