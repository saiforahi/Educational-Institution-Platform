
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main_body_container">
        <?php echo $__env->make('layouts.body_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Body Center Side-->
        <div class="n_center_body" id="newsfeed_body">
            <div class="newsfeed_container">
                <?php if(Auth::user()->admin): ?>
                <create-news-component @news_created="update_news_list"></create-news-component>
                <?php endif; ?>
                <show-news-component :news_list="newsData"></show-news-component>
            </div>
        </div>
        <!--Body Center Side-->
        <?php echo $__env->make('layouts.body_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/pages/new_newsfeed.blade.php ENDPATH**/ ?>