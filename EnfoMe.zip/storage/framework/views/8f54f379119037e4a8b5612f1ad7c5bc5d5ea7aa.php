<div class="left_right_side_menu_responsive">
    <div class="l_r_s_m_container">
        <nav>
            <ul>
                <li>
                    <div class="mobile_profile">
                        <p>Profile</p>
                    </div>
                </li>
                <li>
                    <div class="mobile_notification">
                        <p>Notification</p>
                    </div>
                </li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item</a></li>
                <li><a href="#">Demo Menu Item Last</a></li>
            </ul>
        </nav>
    </div>
    <div class="l_r_s_m_down_arrow">
        <i class="fas fa-arrow-circle-down"></i>
    </div>
</div><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/includes/responsive_right_left.blade.php ENDPATH**/ ?>