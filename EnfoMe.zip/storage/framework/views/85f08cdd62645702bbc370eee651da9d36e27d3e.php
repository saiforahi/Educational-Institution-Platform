
<?php $__env->startSection('content'); ?>
    <div class="institute_list_container">
        <div class="center_institute_list">
            <div class="institute_list_column">
                <a href="<?php echo e(url('institute/list/university')); ?>">
                    <div class="institute_list_row">
                        <h1>Univercity</h1>
                    </div>
                </a>
                <a href="<?php echo e(url('institute/list/school')); ?>">
                    <div class="institute_list_row">
                        <h1>School</h1>
                    </div>
                </a>
            </div>
            <div class="institute_list_column">
                <a href="<?php echo e(url('institute/list/college')); ?>">
                    <div class="institute_list_row">
                        <h1>College</h1>
                    </div>
                </a>
                <a href="<?php echo e(url('institute/list/private')); ?>">
                    <div class="institute_list_row">
                        <h1>Private Institute</h1>
                    </div>
                </a>
            </div>
            <div class="institute_list_column">
                <a href="<?php echo e(url('institute/list/diploma')); ?>">
                    <div class="institute_list_row">
                        <h1>Diploma</h1>
                    </div>
                </a>
                <a href="<?php echo e(url('institute/list/national')); ?>">
                    <div class="institute_list_row">
                        <h1>National Univercity</h1>
                    </div>
                </a>
            </div>
            <div class="institute_list_column">
                <a href="<?php echo e(url('institute/list/govt')); ?>">
                    <div class="institute_list_row">
                        <h1>Government Office</h1>
                    </div>
                </a>
                <a href="<?php echo e(url('institute/list/corporate')); ?>">
                    <div class="institute_list_row">
                        <h1>Corporate Office</h1>
                    </div>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/pages/institutes/institute.blade.php ENDPATH**/ ?>