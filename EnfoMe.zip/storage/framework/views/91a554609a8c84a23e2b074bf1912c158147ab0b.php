
<?php $__env->startSection('content'); ?>
    <div class="institute_list_inner_container">
        <div class="institute_list_inner_center">
            <div class="institute_list_inner_header">
                <h1><?php echo e($type); ?></h1>
            </div>
            <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="institute_list_serial">
                <div class="institute_list_logo">
                    <h1><?php echo e($institute->name[0]); ?></h1>
                </div>
                <div class="institute_list_name">
                    <a href="<?php echo e(url('institute/details/'.$institute->id)); ?>"><h1><?php echo e($institute->name); ?></h1></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

        
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/pages/institutes/institute_list.blade.php ENDPATH**/ ?>