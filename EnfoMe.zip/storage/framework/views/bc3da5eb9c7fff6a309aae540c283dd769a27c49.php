<!--Body right Side-->
<div class="n_right_body">
    <div class="right_s_e_container">
        <div class="r_main_header">
            <h3>Sponsored</h3>
        </div>
        <a href="#">
            <div class="sponsored_container">
                <div class="image_con">
                    <img src="https://images.pexels.com/photos/3088160/pexels-photo-3088160.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="Image">
                </div>
                <div class="text_con">
                    <div class="headline_ad">
                        <p>Advertisement headline text goes here.</p>
                    </div>
                    <div class="website_ad">
                        <p>www.website.com</p>
                    </div>
                </div>
            </div>
        </a>
        <a href="#">
            <div class="sponsored_container">
                <div class="image_con">
                    <img src="https://images.pexels.com/photos/4553618/pexels-photo-4553618.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="Image">
                </div>
                <div class="text_con">
                    <div class="headline_ad">
                        <p>Advertisement headline text goes here.</p>
                    </div>
                    <div class="website_ad">
                        <p>www.website.com</p>
                    </div>
                </div>
            </div>
        </a>
        <a href="#">
            <div class="sponsored_container">
                <div class="image_con">
                    <img src="https://images.pexels.com/photos/2422256/pexels-photo-2422256.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="Image">
                </div>
                <div class="text_con">
                    <div class="headline_ad">
                        <p>Advertisement headline text goes here.</p>
                    </div>
                    <div class="website_ad">
                        <p>www.website.com</p>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
<!--Body right Side--><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/layouts/body_right.blade.php ENDPATH**/ ?>