
<?php $__env->startSection('content'); ?>
<section class="body_area">
    <div class="body_container">
        <!--Demo content-->
        <div style="background-color:aqua;width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(58, 155, 155);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(220, 131, 255);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(202, 155, 0);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(111, 214, 70);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(255, 115, 115);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(0, 53, 53);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(176, 170, 255);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(58, 255, 255);width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(153, 153, 153);width: 300px;height: 300px;"></div>
        <div style="background-color:aqua;width: 300px;height: 300px;"></div>
        <div style="background-color:rgb(214, 0, 168);width: 300px;height: 300px;"></div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/sections/newsfeed.blade.php ENDPATH**/ ?>