
<?php $__env->startSection('content'); ?>
<div class="newsfeed_container">
    <div class="center_newsfeed" id="newsfeed_body">
        <?php if(Auth::user()->admin): ?>
            <create-news-component @news_created="update_news_list"></create-news-component>
        <?php endif; ?>
        <show-news-component :news_list="newsData"></show-news-component>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EnfoMe\resources\views/pages/newsfeed.blade.php ENDPATH**/ ?>